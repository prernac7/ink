-- CreateIndex
CREATE INDEX "Collection_curatorId_idx" ON "Collection"("curatorId");
